# MASTER PIPELINE — GSE199248 AMR Transcriptomics

This file consolidates the project workflow from setup through final verification.

## Step 0 — Enter the project

```bash
cd ~/AMR_RNAseq_Transcriptomics
```

Create/activate the project virtual environment:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

Check the environment:

```bash
python --version
R --version
```

Check key tools:

```bash
fastqc --version
fastp --version
multiqc --version
```

## Step 1 — Install Python packages

```bash
python -m pip install --upgrade pip
python -m pip install pandas openpyxl matplotlib scikit-learn statsmodels
```

## Step 2 — Project structure

```bash
mkdir -p data/raw data/processed data/metadata scripts results/qc results/alignment results/differential_expression results/enrichment results/figures docs references
```

## Step 3 — Dataset and metadata

Dataset:

```text
GEO accession: GSE199248
Organism: Escherichia coli
Samples: GSM5968104–GSM5968123
```

The project uses:

```text
data/metadata/GSE199248_metadata.txt
data/metadata/GSE199199248_series_matrix.txt
data/metadata/GSE199248_series_matrix.txt.gz
data/metadata/sample_mapping.tsv
data/processed/GSE199248_RNA-Seq_ProcessedData.xlsx
data/processed/GSE199248_raw_counts_clean.tsv
```

If the repository contains the series-matrix file, verify it:

```bash
ls -lh data/metadata
```

Verify the processed workbook:

```bash
ls -lh data/processed
```

## Step 4 — Verify the raw-count matrix

The raw-count table contains 24 columns:

- 4 metadata columns
- 20 GSM sample columns

The correct QC command is:

```bash
python -c 'import pandas as pd; f="data/processed/GSE199248_raw_counts_clean.tsv"; df=pd.read_csv(f,sep="\t"); sample_cols=[c for c in df.columns if c.startswith("GSM")]; print("Total columns:",len(df.columns)); print("RNA-seq sample columns:",len(sample_cols)); print("Number of genes:",df.shape[0]); counts=df[sample_cols].apply(pd.to_numeric,errors="coerce"); total_counts=counts.sum(axis=1); print("Completely zero-count genes:",(total_counts==0).sum()); print("Genes with total count <10:",(total_counts<10).sum())'
```

Expected result:

```text
Total columns: 24
RNA-seq sample columns: 20
Number of genes: 4513
Completely zero-count genes: 1
Genes with total count <10: 38
```

Important: do not use `df.columns[1:]` for the count calculation because the first four columns contain metadata.

## Step 5 — Library-size QC

The project output is:

```text
results/qc/library_size.tsv
```

and figure:

```text
results/figures/library_size.png
```

The count matrix should be interpreted using only the 20 `GSM...` columns.

## Step 6 — Count-distribution QC

Output:

```text
results/figures/count_distribution_boxplot.png
```

## Step 7 — PCA

PCA was performed using:

1. genes with total count >= 10
2. log2(count + 1)
3. top 1000 most-variable genes
4. StandardScaler
5. PCA with two components

Output:

```text
results/qc/PCA_coordinates.tsv
results/figures/PCA_samples.png
```

## Step 8 — Sample mapping

The sample mapping is:

```text
GSM5968104 Uninduced WT CAT-I   CAT-I Uninduced_WT
GSM5968105 Induced WT CAT-I     CAT-I Induced_WT
GSM5968106 S27M CAT-I           CAT-I Mutant
GSM5968107 Q30M CAT-I           CAT-I Mutant
GSM5968108 S155R CAT-I          CAT-I Mutant
GSM5968109 G202R CAT-I          CAT-I Mutant
GSM5968110 G202K CAT-I          CAT-I Mutant
GSM5968111 Uninduced WT NDM-1   NDM-1 Uninduced_WT
GSM5968112 Induced WT NDM-1     NDM-1 Induced_WT
GSM5968113 G25C NDM-1           NDM-1 Mutant
GSM5968114 G25S NDM-1           NDM-1 Mutant
GSM5968115 G25T NDM-1           NDM-1 Mutant
GSM5968116 C26S NDM-1           NDM-1 Mutant
GSM5968117 C26D NDM-1           NDM-1 Mutant
GSM5968118 P28A NDM-1           NDM-1 Mutant
GSM5968119 Uninduced WT AadB    AadB Uninduced_WT
GSM5968120 Induced WT AadB      AadB Induced_WT
GSM5968121 Delta Gene           AadB Mutant
GSM5968122 A102L AadB           AadB Mutant
GSM5968123 D143F AadB           AadB Mutant
```

## Step 9 — Differential-expression data

The project uses the study-provided processed sheets:

```text
Fold-difference
P-value
Variance
Raw Counts
```

These are stored in:

```text
data/processed/GSE199248_RNA-Seq_ProcessedData.xlsx
```

Because there are no biological replicates for the individual mutation conditions, standard DESeq2 replicate-based inference is not used.

## Step 10 — Mutation-wise FDR

For each mutation:

1. start with the study-provided P-values
2. apply Benjamini-Hochberg correction
3. define significant genes as:

```text
FDR < 0.05
AND
|log2FC| >= 1
```

The fold-difference equivalent is:

```text
Fold-difference >= 2  -> upregulated
Fold-difference <= 0.5 -> downregulated
```

Main summary:

```text
results/differential_expression/FDR_filtered/FDR_DEG_summary.tsv
```

Mutation-specific files:

```text
results/differential_expression/FDR_filtered/NDM1_all_FDR.tsv
results/differential_expression/FDR_filtered/NDM1_significant_DEGs.tsv
results/differential_expression/FDR_filtered/CATI_all_FDR.tsv
results/differential_expression/FDR_filtered/CATI_significant_DEGs.tsv
results/differential_expression/FDR_filtered/AadB_all_FDR.tsv
results/differential_expression/FDR_filtered/AadB_significant_DEGs.tsv
```

## Step 11 — Verify DEG arithmetic

Run:

```bash
awk 'NR>1 && ($5+$6)!=$4 {print "MISMATCH:", $0}' results/differential_expression/FDR_filtered/FDR_DEG_summary.tsv
```

Expected output:

```text
(no output)
```

This confirms:

```text
Upregulated + Downregulated = Significant_DEGs
```

## Step 12 — Verify cumulative counts

```bash
python -c 'import pandas as pd; d=pd.read_csv("results/differential_expression/FDR_filtered/FDR_DEG_summary.tsv",sep="\t"); print(d.groupby("Gene")[["Significant_DEGs","Upregulated","Downregulated"]].sum())'
```

Expected:

```text
      Significant_DEGs  Upregulated  Downregulated
Gene
AadB              4178          987           3191
CATI              2513          565           1948
NDM1              2327         1807            520
```

These are cumulative counts across mutations, not unique genes.

## Step 13 — Prepare enrichment inputs

Mutation-specific DEG gene lists:

```text
results/enrichment/
```

Group-specific backgrounds:

```text
NDM1_background_genes.txt
CATI_background_genes.txt
AadB_background_genes.txt
```

Input summary:

```text
results/enrichment/enrichment_input_summary.tsv
```

## Step 14 — Gene-ID mapping

The analysis uses:

```text
org.EcK12.eg.db
AnnotationDbi
```

Mapping outputs:

```text
results/enrichment/GO_KEGG/
```

## Step 15 — GO enrichment

Script:

```text
scripts/run_GO_enrichment.R
```

Run from the project root:

```bash
Rscript scripts/run_GO_enrichment.R
```

Method:

- Fisher exact test
- group-specific background
- Benjamini-Hochberg correction

Outputs:

```text
results/enrichment/GO_results/
results/enrichment/GO_results/significant/
results/enrichment/GO_results/significant/GO_significant_summary.tsv
```

## Step 16 — KEGG enrichment

Script:

```text
scripts/run_KEGG_enrichment.R
```

Run:

```bash
Rscript scripts/run_KEGG_enrichment.R
```

Method:

- E. coli K-12 KEGG mapping
- Fisher exact test
- Benjamini-Hochberg correction

Outputs:

```text
results/enrichment/KEGG_results/
results/enrichment/KEGG_results/significant/
results/enrichment/KEGG_results/significant/KEGG_significant_summary.tsv
```

## Step 17 — Add KEGG pathway names

Script:

```text
scripts/add_KEGG_pathway_names.R
```

Run:

```bash
Rscript scripts/add_KEGG_pathway_names.R
```

Output:

```text
results/enrichment/Top10_KEGG_pathways_named.tsv
```

## Step 18 — Plot KEGG enrichment

Script:

```text
scripts/plot_KEGG_enrichment.py
```

Run:

```bash
python scripts/plot_KEGG_enrichment.py
```

Figures:

```text
results/figures/KEGG_enrichment/NDM1_KEGG_enrichment.png
results/figures/KEGG_enrichment/CATI_KEGG_enrichment.png
results/figures/KEGG_enrichment/AadB_KEGG_enrichment.png
```

## Step 19 — Final figures

Main figures:

```text
results/figures/PCA_samples.png
results/figures/final/DEG_count_by_mutation.png
results/figures/final/UpDown_DEGs_by_mutation.png
results/figures/final/GO_KEGG_Enrichment_Comparison.png
results/figures/Biological_theme_comparison_heatmap.png
```

## Step 20 — Final result tables

```text
results/FINAL_RESULTS_SUMMARY.tsv
results/enrichment/Final_biological_interpretation.tsv
results/enrichment/Final_key_biological_findings.tsv
results/enrichment/Final_gene_level_summary.tsv
```

## Step 21 — Final project verification

Check for zero-byte result/document files:

```bash
find results docs -type f -size 0 -print
```

Expected output:

```text
(no output)
```

Count project files while excluding the virtual environment:

```bash
find . -type f -not -path "./.venv/*" | wc -l
```

Verified project count at final analysis stage:

```text
208 files
```

## Step 22 — Check scripts

```bash
ls -lh scripts
```

Current analysis scripts:

```text
scripts/add_KEGG_pathway_names.R
scripts/plot_KEGG_enrichment.py
scripts/run_GO_enrichment.R
scripts/run_KEGG_enrichment.R
scripts/run_enrichment.R
scripts/run_logged.sh
```

## Step 23 — GitHub preparation

Before pushing, inspect the repository:

```bash
git status
```

Check that the virtual environment is excluded:

```bash
git status --short
```

The `.venv/` directory should not be committed.

## Reproducibility note

This repository documents the analysis actually performed. It does not claim that missing historical one-off commands were generated from nonexistent scripts.

The complete workflow is therefore documented as:

```text
Dataset/metadata
→ count-matrix verification
→ QC
→ PCA
→ study-provided Fold-difference/P-value processing
→ mutation-wise BH-FDR
→ DEG filtering
→ gene-ID mapping
→ GO enrichment
→ KEGG enrichment
→ pathway-name annotation
→ visualization
→ biological interpretation
→ final verification
```

## Final scientific interpretation

The project identifies mutation-associated transcriptional changes and statistically enriched biological processes/pathways. The findings should be interpreted as **associations**, not causal mechanisms.

The strongest recurring patterns were:

- NDM1: predominantly upregulated genes with recurring cell-envelope/extracellular, iron/siderophore, transport, sulfur, and energy/metabolic themes.
- CATI: predominantly downregulated genes with mutation-specific metabolic, antimicrobial-resistance, siderophore, and motility themes.
- AadB: predominantly downregulated genes; Delta_Gene showed enrichment in branched-chain amino-acid biosynthesis, while A102L and D143F had many DEGs without significant GO/KEGG enrichment under the selected criteria.
