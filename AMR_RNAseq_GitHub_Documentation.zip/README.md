# Transcriptome-Based Identification of Differentially Expressed Genes and Biological Pathways Associated with Antimicrobial Resistance

## Project overview

This repository contains a computational transcriptomics analysis of **E. coli** RNA-seq data from **GEO accession GSE199248**.

The project investigates transcriptional changes associated with mutations in three antibiotic-resistance genes:

- **NDM-1**
- **CAT-I**
- **AadB**

The workflow uses the study-provided processed expression data and performs quality checks, mutation-wise differential-expression filtering, multiple-testing correction, Gene Ontology (GO) enrichment, KEGG pathway enrichment, visualization, and biological interpretation.

> **Important methodological note:** The dataset contains single samples for the individual mutation conditions rather than biological replicates. Therefore, this project does **not** use standard replicate-based DESeq2 inference. Differential-expression significance is based on the study-provided `Fold-difference` and `P-value` tables, followed by mutation-wise Benjamini-Hochberg FDR correction.

## Dataset

- **GEO:** GSE199248
- **Organism:** *Escherichia coli*
- **Study:** Landscapes of collateral fitness effects of mutations in antibiotic resistance genes
- **Samples:** 20
- **Genes in raw count matrix:** 4,513
- **Completely zero-count genes:** 1
- **Genes with total count <10:** 38
- **PubMed:** 36798991

### Mutation groups

| Gene | Mutations analysed |
|---|---|
| NDM1 | G25C, G25S, G25T, C26S, C26D, P28A |
| CATI | S27M, Q30M, S155R, G202R, G202K |
| AadB | Delta_Gene, A102L, D143F |

## Analysis workflow

```text
GSE199248
   │
   ├── GEO metadata / processed expression data
   │
   ├── Sample mapping
   │
   ├── Raw-count matrix QC
   │     ├── sample-column verification
   │     ├── gene-count checks
   │     └── library-size assessment
   │
   ├── PCA
   │     └── log2(count + 1), top-variable genes
   │
   ├── Mutation-wise differential-expression filtering
   │     ├── study Fold-difference
   │     ├── study P-value
   │     ├── BH-FDR
   │     └── |log2FC| >= 1 and FDR < 0.05
   │
   ├── GO enrichment
   │     └── Fisher exact test + BH correction
   │
   ├── KEGG enrichment
   │     └── Fisher exact test + BH correction
   │
   ├── Pathway-name annotation
   │
   ├── Figures
   │
   └── Biological interpretation + limitations
```

## Repository structure

```text
AMR_RNAseq_Transcriptomics/
├── README.md
├── data/
│   ├── raw/
│   ├── processed/
│   └── metadata/
├── scripts/
│   ├── add_KEGG_pathway_names.R
│   ├── plot_KEGG_enrichment.py
│   ├── run_GO_enrichment.R
│   ├── run_KEGG_enrichment.R
│   ├── run_enrichment.R
│   └── run_logged.sh
├── results/
│   ├── qc/
│   ├── alignment/
│   ├── differential_expression/
│   ├── enrichment/
│   └── figures/
├── docs/
│   ├── MASTER_PIPELINE.md
│   ├── COMMANDS.md
│   └── RESULTS.md
└── references/
    └── references.md
```

## Software environment

The completed analysis was performed with:

- Python 3.14
- R 4.5.2
- FastQC 0.12.1
- fastp 1.0.1
- MultiQC 1.21
- pandas 3.0.6
- matplotlib 3.11.2
- scikit-learn 1.9.1
- statsmodels 0.15.0
- Bioconductor packages including:
  - AnnotationDbi
  - org.EcK12.eg.db
  - GO.db
  - KEGGREST

## Main thresholds

Differential-expression filtering:

```text
FDR < 0.05
AND
|log2FC| >= 1
```

Equivalent fold-difference interpretation:

```text
Fold-difference >= 2       -> upregulated
Fold-difference <= 0.5     -> downregulated
```

FDR correction was performed separately for each mutation using the Benjamini-Hochberg procedure.

## Main results

### Cumulative significant DEGs by resistance gene

| Gene | Mutations | Cumulative significant DEGs | Upregulated | Downregulated |
|---|---:|---:|---:|---:|
| NDM1 | 6 | 2327 | 1807 | 520 |
| CATI | 5 | 2513 | 565 | 1948 |
| AadB | 3 | 4178 | 987 | 3191 |

These are **cumulative counts across mutation conditions**, not counts of unique genes across all mutations.

### Biological themes

**NDM1 mutations:** recurring enrichment related to cell-envelope/extracellular processes, siderophore/iron biology, transport, sulfur metabolism, and energy/central metabolism.

**CATI mutations:** predominantly downregulated genes, with mutation-specific enrichment involving central carbon metabolism, energy metabolism, amino-acid metabolism, siderophore biology, antimicrobial resistance, and flagellar/motility functions.

**AadB mutations:** predominantly downregulated genes. Delta_Gene showed enrichment involving branched-chain amino-acid biosynthesis, whereas A102L and D143F produced many significant genes but no significant GO/KEGG enrichment under the selected criteria.

## Important limitations

1. Individual mutation conditions do not have biological replicates.
2. Standard replicate-based DESeq2 inference was therefore not applied.
3. Differential-expression statistics originate from the study-provided processed `Fold-difference` and `P-value` tables.
4. FDR correction is mutation-wise.
5. GO/KEGG enrichment depends on gene-ID mapping and annotation coverage.
6. Significant enrichment represents statistical association and does not establish causality.
7. A lack of significant GO/KEGG terms does not prove that a mutation has no biological effect.

## Key output files

```text
results/FINAL_RESULTS_SUMMARY.tsv
results/differential_expression/FDR_filtered/FDR_DEG_summary.tsv
results/enrichment/Final_biological_interpretation.tsv
results/enrichment/Final_key_biological_findings.tsv
results/enrichment/Final_gene_level_summary.tsv
results/figures/PCA_samples.png
results/figures/final/DEG_count_by_mutation.png
results/figures/final/UpDown_DEGs_by_mutation.png
results/figures/final/GO_KEGG_Enrichment_Comparison.png
results/figures/Biological_theme_comparison_heatmap.png
```

## Reproducibility

The complete command history and methodological workflow are documented in:

**`docs/MASTER_PIPELINE.md`**

The project-specific command documentation is retained in:

**`docs/COMMANDS.md`**

The detailed interpretation and results are retained in:

**`docs/RESULTS.md`**

## Citation

If you use this repository, cite the original GEO study and the software/database resources used for the analysis.

See:

```text
references/references.md
```
